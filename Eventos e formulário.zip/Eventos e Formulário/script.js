document.addEventListener('DOMContentLoaded', function() {
    const taskForm = document.getElementById('task-form');
    const taskNameInput = document.getElementById('name');
    const taskDateInput = document.getElementById('date');
    const taskPrioritySelect = document.getElementById('prioridade');
    const nameError = document.getElementById('name-erro');
    const tasksContainer = document.getElementById('tasks-formulario');
    const emptyMessage = document.getElementById('empty-message');
    
    let tasks = [];
    
    function addTask(event) {
        event.preventDefault();
        
        if (taskNameInput.value.trim() === '') {
            nameError.style.display = 'block';
            return;
        } else {
            nameError.style.display = 'none';
        }
        
        const taskName = taskNameInput.value.trim();
        const taskDate = taskDateInput.value;
        const taskPriority = taskPrioritySelect.value;
        
        const task = {
            id: Date.now(), 
            name: taskName,
            date: taskDate,
            priority: taskPriority
        };
        
        tasks.push(task);
        
        renderTasks();
        
        taskForm.reset();
    }
    
    function renderTasks() {
        if (tasks.length > 0) {
            emptyMessage.style.display = 'none';
        } else {
            emptyMessage.style.display = 'block';
        }
        
        tasksContainer.innerHTML = '';
        
        tasks.forEach(task => {
            const taskElement = document.createElement('div');
            taskElement.className = 'task-item';
            
            let formattedDate = 'Sem data limite';
            if (task.date) {
                const dateObj = new Date(task.date);
                formattedDate = dateObj.toLocaleDateString('pt-BR');
            }
            
            let priorityClass = '';
            let priorityText = '';
            switch(task.priority) {
                case 'alta':
                    priorityClass = 'priority-alta';
                    priorityText = 'Alta';
                    break;
                case 'media':
                    priorityClass = 'priority-media';
                    priorityText = 'Média';
                    break;
                case 'baixa':
                    priorityClass = 'priority-baixa';
                    priorityText = 'Baixa';
                    break;
            }
            
            taskElement.innerHTML = `
                <div class="task-info">
                    <div class="task-name">${task.name}</div>
                    <div class="task-details">
                        ${formattedDate} 
                        <span class="priority ${priorityClass}">${priorityText}</span>
                    </div>
                </div>
                <button class="remove-btn" data-id="${task.id}">Remover</button>
            `;
            
            tasksContainer.appendChild(taskElement);
        });
        
        const removeButtons = document.querySelectorAll('.remove-btn');
        removeButtons.forEach(button => {
            button.addEventListener('click', function() {
                const taskId = parseInt(this.getAttribute('data-id'));
                removeTask(taskId);
            });
        });
    }
    
    function removeTask(taskId) {
        tasks = tasks.filter(task => task.id !== taskId);
        renderTasks();
    }
    
    taskForm.addEventListener('submit', addTask);
});